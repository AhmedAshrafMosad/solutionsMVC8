using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SchoolManagement.Views.Department
{
    public class ShowDetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
