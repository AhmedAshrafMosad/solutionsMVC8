using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SchoolManagement.Views.Department
{
    public class GetAllModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
