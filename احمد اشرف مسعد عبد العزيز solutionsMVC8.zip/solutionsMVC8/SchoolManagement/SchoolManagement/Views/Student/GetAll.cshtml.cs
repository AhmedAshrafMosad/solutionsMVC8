using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SchoolManagement.Views.Student
{
    public class GetAllModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
