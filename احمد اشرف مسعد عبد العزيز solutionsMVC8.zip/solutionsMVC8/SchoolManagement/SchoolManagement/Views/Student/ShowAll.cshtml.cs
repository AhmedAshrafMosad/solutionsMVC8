using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SchoolManagement.Views.Student
{
    public class ShowAllModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
