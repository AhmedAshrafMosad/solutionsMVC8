using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SchoolManagement.Views.Student
{
    public class GetByIdModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
