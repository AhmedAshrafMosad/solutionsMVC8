using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SchoolManagement.Views.Course
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
