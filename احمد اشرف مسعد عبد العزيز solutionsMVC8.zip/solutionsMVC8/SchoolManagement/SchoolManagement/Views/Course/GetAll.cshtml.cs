using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SchoolManagement.Views.Course
{
    public class GetAllModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
