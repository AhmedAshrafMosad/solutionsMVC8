using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SchoolManagement.Views.Course
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
